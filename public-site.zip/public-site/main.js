const siteHeader = document.getElementById("siteHeader");
const hero = document.querySelector(".hero");
const menuToggle = document.getElementById("menuToggle");
const primaryNav = document.getElementById("primaryNav");
const languageToggle = document.getElementById("languageToggle");
const floatingLanguageToggle = document.querySelector('[data-language-toggle="floating"]');
const languageToggleButtons = document.querySelectorAll('[data-language-toggle]');
const activeLanguageToggle = languageToggle || floatingLanguageToggle || languageToggleButtons[0];
let framePending = false;

const translations = {
    ar: {
        brandName: 'قمة الازدهار',
        brandSub: 'لصناعة الكرتون',
        navHome: 'الرئيسية',
        navAbout: 'عن المصنع',
        navSolutions: 'حلولنا',
        navContact: 'تواصل معنا',
        navCatalog: 'دليل المنتجات',
        navLogin: 'دخول النظام',
        heroEyebrow: 'من شملان، صنعاء · منذ 2025',
        heroTitle: 'تغليف يحمي منتجك',
        heroTitleEm: 'ويحكي قصتك',
        heroDescription: 'حلول كرتونية وورقية مصممة لترافق أعمالك من خط الإنتاج إلى وجهتها.',
        heroPrimaryBtn: 'اكتشف حلولنا',
        heroSecondaryBtn: 'اطلب عرض سعر',
        heroAside: 'كرتون مموج<br>مصنوع بعناية',
        aboutKicker: 'عن قمة الازدهار',
        aboutTitle: 'نصنع أساسًا<br><em>لأعمال تنمو.</em>',
        aboutLead: 'من شملان في صنعاء، انطلقت قمة الازدهار عام 2025 لتقديم حلول عملية في صناعة الكرتون المموج والتغليف الورقي.',
        aboutText: 'نطوّر عبوات تساعد المنتجات على الوصول بأمان وتمنح كل نشاط مساحة ليظهر بطريقته؛ من الكراتين المخصصة للطباعة إلى الأشكال المصممة حسب الطلب والمنتجات الورقية.',
        aboutLink: 'تعرّف على حلولنا',
        stampTop: 'قمة الازدهار',
        stampCenter: 'صنعاء',
        stampBottom: 'صناعة يمنية · 2025',
        solutionsKicker: 'من الفكرة إلى العبوة',
        solutionsTitle: 'حلولنا <em>التغليفية</em>',
        solutionsText: 'خيارات متنوعة للمصانع والمتاجر والعلامات التجارية، بتصاميم تلائم طبيعة المنتج وطريقة نقله.',
        cardTitle1: 'كرتون بطباعة عالية الدقة',
        cardText1: 'مساحة واضحة لهوية المنتج، مع طباعة تساعد العبوة على لفت الانتباه.',
        cardTitle2: 'عبوات بقوالب مخصصة',
        cardText2: 'أشكال مقصوصة ومطوية لتناسب المنتج وتوفر تثبيتًا وحماية أفضل.',
        cardTitle3: 'كراتين الشحن والتخزين',
        cardText3: 'حل عملي للتعبئة والنقل والتخزين، بمقاسات تخدم احتياج النشاط.',
        cardTitle4: 'لفائف ومواد حماية',
        cardText4: 'لفائف وحواجز ورقية للمساعدة في حماية المنتجات أثناء النقل.',
        solutionsNote: 'تتوفر أيضًا الأكياس والأكواب الورقية، وحلول تغليف أخرى حسب الطلب.',
        solutionsNoteLink: 'ناقش احتياجك',
        craftKicker: 'تفاصيل تصنع الفرق',
        craftTitle: 'من طبقات الورق<br>إلى <em>ثقة تصل.</em>',
        craftText: 'نهتم بجودة التصنيع والطباعة وخدمة العملاء، ونطوّر حلولًا تغليفية تتناسب مع متطلبات كل مشروع.',
        craftBtn: 'لنتحدث عن مشروعك',
        contactKicker: 'نبدأ من احتياجك',
        contactTitle: 'لنتحدث عن<br><em>التغليف المناسب.</em>',
        contactBtn: 'تواصل عبر واتساب',
        locationLabel: 'الموقع',
        locationText: 'شملان، صنعاء، اليمن',
        callLabel: 'اتصل بنا',
        browseLabel: 'تصفّح',
        browseCatalog: 'دليل المنتجات',
        browseLogin: 'دخول النظام',
        footerBrand: 'قمة الازدهار',
        footerBrandSub: 'لصناعة الكرتون',
        footerText: 'صناعة تغليف تبدأ من صنعاء وتصل إلى احتياجك.',
        footerCopy: '© 2026 قمة الازدهار',
        scrollCue: 'مرر للتعرّف علينا',
        languageLabel: 'EN',
        catalogNavHome: 'الرئيسية',
        catalogNavProducts: 'دليل المنتجات',
        catalogNavLogin: 'دخول النظام',
        catalogContact: 'تواصل معنا',
        catalogScroll: 'استكشف المنتجات',
        catalogIntroKicker: 'من شملان، صنعاء · حلول تغليف',
        catalogIntroTitle: 'كل منتج له<br><em>عبوته المناسبة.</em>',
        catalogIntroDescription: 'تعرّف على حلولنا من الكرتون المموج والتغليف الورقي، واختر ما يناسب منتجك وطريقة وصوله.',
        catalogSectionKicker: 'كتالوج قمة الازدهار',
        catalogProductsTitle: 'حلول من الورق،<br><em>مصنوعة لتعمل.</em>',
        catalogProductsText: 'مرّر على البطاقة أو اضغط عليها لتفاصيل المنتج. لكل استخدام شكل يحميه ويخدمه.',
        catalogNoteTitle: 'تحتاج مقاسًا أو فكرة مختلفة؟',
        catalogNoteText: 'الأكياس والأكواب الورقية وحلول التغليف الخاصة متاحة للاستفسار.',
        catalogNoteLink: 'ناقش مشروعك',
        catalogFooterBrand: 'قمة الازدهار',
        catalogFooterBrandSub: 'لصناعة الكرتون',
        catalogFooterLocation: 'شملان، صنعاء، اليمن',
        catalogFooterPhone: '+967 784441556'
    },
    en: {
        brandName: 'Qumat Al-Izdihar',
        brandSub: 'Packaging Factory',
        navHome: 'Home',
        navAbout: 'About',
        navSolutions: 'Solutions',
        navContact: 'Contact',
        navCatalog: 'Product Guide',
        navLogin: 'Login',
        heroEyebrow: 'From Shamlan, Sana\'a • Since 2025',
        heroTitle: 'Packaging that protects your product',
        heroTitleEm: 'and tells your story',
        heroDescription: 'Cardboard and paper solutions designed to support your business from production line to destination.',
        heroPrimaryBtn: 'Discover our solutions',
        heroSecondaryBtn: 'Request a quote',
        heroAside: 'Corrugated box<br>crafted with care',
        aboutKicker: 'About Qumat Al-Izdihar',
        aboutTitle: 'We build the foundation<br><em>for businesses that grow.</em>',
        aboutLead: 'From Shamlan in Sana\'a, Qumat Al-Izdihar began in 2025 to offer practical solutions in corrugated cardboard and paper packaging.',
        aboutText: 'We develop packaging that helps products reach safely and gives each business room to stand out; from custom printed boxes to tailored shapes and paper products.',
        aboutLink: 'Explore our solutions',
        stampTop: 'Qumat Al-Izdihar',
        stampCenter: 'Sana\'a',
        stampBottom: 'Yemeni manufacturing • 2025',
        solutionsKicker: 'From idea to packaging',
        solutionsTitle: 'Our <em>Packaging</em> Solutions',
        solutionsText: 'A wide range of options for factories, shops, and brands, designed to fit each product and handling method.',
        cardTitle1: 'High-precision printed carton',
        cardText1: 'A clear presentation for your brand, with print quality that helps your packaging stand out.',
        cardTitle2: 'Custom die-cut boxes',
        cardText2: 'Cut and folded shapes designed to match your product and provide better protection and fit.',
        cardTitle3: 'Shipping and storage cartons',
        cardText3: 'Practical packaging for storage and transport, available in dimensions suited to your needs.',
        cardTitle4: 'Protective rolls and materials',
        cardText4: 'Flexible corrugated rolls and paper dividers to help protect products during transit.',
        solutionsNote: 'We also offer paper bags, cups, and other packaging solutions tailored to your order.',
        solutionsNoteLink: 'Discuss your needs',
        craftKicker: 'Details that make the difference',
        craftTitle: 'From layers of paper<br>to <em>trusted delivery.</em>',
        craftText: 'We focus on production quality, print finish, and customer service, while developing packaging solutions that match each project.',
        craftBtn: 'Let\'s talk about your project',
        contactKicker: 'We start from your need',
        contactTitle: 'Let\'s talk about<br><em>the right packaging.</em>',
        contactBtn: 'Contact via WhatsApp',
        locationLabel: 'Location',
        locationText: 'Shamlan, Sana\'a, Yemen',
        callLabel: 'Call us',
        browseLabel: 'Browse',
        browseCatalog: 'Product guide',
        browseLogin: 'System login',
        footerBrand: 'Qumat Al-Izdihar',
        footerBrandSub: 'Packaging Factory',
        footerText: 'Packaging made in Sana\'a and delivered to your needs.',
        footerCopy: '© 2026 Qumat Al-Izdihar',
        scrollCue: 'Scroll to learn more',
        languageLabel: 'AR',
        catalogNavHome: 'Home',
        catalogNavProducts: 'Product guide',
        catalogNavLogin: 'Login',
        catalogContact: 'Contact us',
        catalogScroll: 'Explore products',
        catalogIntroKicker: 'From Shamlan, Sana\'a • Packaging solutions',
        catalogIntroTitle: 'Every product deserves<br><em>its perfect box.</em>',
        catalogIntroDescription: 'Explore our corrugated cardboard and paper packaging solutions and choose the right fit for your product and delivery method.',
        catalogSectionKicker: 'Qumat Al-Izdihar catalog',
        catalogProductsTitle: 'Paper solutions,<br><em>made to perform.</em>',
        catalogProductsText: 'Swipe or tap a card for more product details. Every use case deserves a protective, purpose-built format.',
        catalogNoteTitle: 'Need a different size or idea?',
        catalogNoteText: 'Paper bags, cups, and custom packaging solutions are available upon request.',
        catalogNoteLink: 'Discuss your project',
        catalogFooterBrand: 'Qumat Al-Izdihar',
        catalogFooterBrandSub: 'Packaging Factory',
        catalogFooterLocation: 'Shamlan, Sana\'a, Yemen',
        catalogFooterPhone: '+967 784441556'
    }
};

const pageTextMap = {
    brandName: 'brandName',
    brandSub: 'brandSub',
    navHome: 'navHome',
    navAbout: 'navAbout',
    navSolutions: 'navSolutions',
    navContact: 'navContact',
    navCatalog: 'navCatalog',
    navLogin: 'navLogin',
    heroEyebrow: 'heroEyebrow',
    heroTitle: 'heroTitle',
    heroTitleEm: 'heroTitleEm',
    heroDescription: 'heroDescription',
    heroPrimaryBtn: 'heroPrimaryBtn',
    heroSecondaryBtn: 'heroSecondaryBtn',
    heroAside: 'heroAside',
    aboutKicker: 'aboutKicker',
    aboutTitle: 'aboutTitle',
    aboutLead: 'aboutLead',
    aboutText: 'aboutText',
    aboutLink: 'aboutLink',
    stampTop: 'stampTop',
    stampCenter: 'stampCenter',
    stampBottom: 'stampBottom',
    solutionsKicker: 'solutionsKicker',
    solutionsTitle: 'solutionsTitle',
    solutionsText: 'solutionsText',
    cardTitle1: 'cardTitle1',
    cardText1: 'cardText1',
    cardTitle2: 'cardTitle2',
    cardText2: 'cardText2',
    cardTitle3: 'cardTitle3',
    cardText3: 'cardText3',
    cardTitle4: 'cardTitle4',
    cardText4: 'cardText4',
    solutionsNote: 'solutionsNote',
    solutionsNoteLink: 'solutionsNoteLink',
    craftKicker: 'craftKicker',
    craftTitle: 'craftTitle',
    craftText: 'craftText',
    craftBtn: 'craftBtn',
    contactKicker: 'contactKicker',
    contactTitle: 'contactTitle',
    contactBtn: 'contactBtn',
    locationLabel: 'locationLabel',
    locationText: 'locationText',
    callLabel: 'callLabel',
    browseLabel: 'browseLabel',
    browseCatalog: 'browseCatalog',
    browseLogin: 'browseLogin',
    footerBrand: 'footerBrand',
    footerBrandSub: 'footerBrandSub',
    footerText: 'footerText',
    footerCopy: 'footerCopy',
    scrollCue: 'scrollCue',
    catalogNavHome: 'catalogNavHome',
    catalogNavProducts: 'catalogNavProducts',
    catalogNavLogin: 'catalogNavLogin',
    catalogContact: 'catalogContact',
    catalogScroll: 'catalogScroll',
    catalogIntroKicker: 'catalogIntroKicker',
    catalogIntroTitle: 'catalogIntroTitle',
    catalogIntroDescription: 'catalogIntroDescription',
    catalogSectionKicker: 'catalogSectionKicker',
    catalogProductsTitle: 'catalogProductsTitle',
    catalogProductsText: 'catalogProductsText',
    catalogNoteTitle: 'catalogNoteTitle',
    catalogNoteText: 'catalogNoteText',
    catalogNoteLink: 'catalogNoteLink',
    catalogFooterBrand: 'catalogFooterBrand',
    catalogFooterBrandSub: 'catalogFooterBrandSub',
    catalogFooterLocation: 'catalogFooterLocation',
    catalogFooterPhone: 'catalogFooterPhone'
};

function applyTranslations(lang) {
    const current = translations[lang] || translations.ar;
    const keys = Object.keys(pageTextMap);

    keys.forEach((key) => {
        const targetId = pageTextMap[key];
        const target = document.getElementById(targetId);
        if (!target) return;

        const value = current[key];
        if (!value) return;

        if (key === 'heroPrimaryBtn' || key === 'aboutLink' || key === 'craftBtn') {
            target.innerHTML = value + ' <span aria-hidden="true">←</span>';
            return;
        }
        if (key === 'contactBtn' || key === 'catalogContact' || key === 'catalogNoteLink') {
            target.innerHTML = value + ' <span aria-hidden="true">↗</span>';
            return;
        }
        if (key === 'catalogScroll') {
            target.innerHTML = '<span></span>' + value;
            return;
        }
        if (key === 'catalogFooterBrand') {
            target.innerHTML = value + ' <span id="catalogFooterBrandSub">' + current.catalogFooterBrandSub + '</span>';
            return;
        }
        if (key === 'aboutTitle' || key === 'solutionsTitle' || key === 'craftTitle' || key === 'contactTitle' || key === 'heroTitleEm' || key === 'heroAside' || key === 'heroTitle' || key === 'catalogIntroTitle' || key === 'catalogProductsTitle') {
            target.innerHTML = value;
            return;
        }

        target.textContent = value;
    });

    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'en' ? 'ltr' : 'rtl';
    document.body.classList.toggle('is-ltr', lang === 'en');

    if (activeLanguageToggle) {
        activeLanguageToggle.textContent = current.languageLabel;
        activeLanguageToggle.setAttribute('aria-label', lang === 'en' ? 'التبديل للعربية' : 'Switch language to English');
    }

    languageToggleButtons.forEach((button) => {
        const isFloating = button.dataset.languageToggle === 'floating';
        button.textContent = isFloating ? (lang === 'ar' ? 'EN' : 'AR') : (lang === 'ar' ? 'EN' : 'AR');
        button.setAttribute('aria-label', lang === 'en' ? 'التبديل للعربية' : 'Switch language to English');
    });

    const scrollCue = document.querySelector('.scroll-cue');
    if (scrollCue) {
        scrollCue.innerHTML = `<span></span>${current.scrollCue}`;
    }
}

let currentLanguage = 'ar';
const toggleLanguage = () => {
    currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
    applyTranslations(currentLanguage);
};

if (activeLanguageToggle) {
    activeLanguageToggle.addEventListener('click', toggleLanguage);
}

languageToggleButtons.forEach((button) => {
    button.addEventListener('click', toggleLanguage);
});

if (floatingLanguageToggle) {
    floatingLanguageToggle.style.left = `${Math.max(18, window.innerWidth - 118)}px`;
    floatingLanguageToggle.style.top = `${Math.max(18, window.innerHeight - 110)}px`;

    const moveFloatingLanguage = (event) => {
        const x = Math.min(window.innerWidth - 84, Math.max(18, event.clientX + 22));
        const y = Math.min(window.innerHeight - 54, Math.max(18, event.clientY + 18));
        floatingLanguageToggle.style.left = `${x}px`;
        floatingLanguageToggle.style.top = `${y}px`;
    };

    window.addEventListener('pointermove', moveFloatingLanguage, { passive: true });
}

applyTranslations(currentLanguage);

function updateScrollState() {
    if (!siteHeader) return;
    const scrollPosition = window.scrollY;
    siteHeader.classList.toggle("is-scrolled", scrollPosition > 30);

    const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    const paperProgress = Math.min(scrollPosition / maxScroll, 1);
    const cartonTone = [222, 194, 151];
    const whiteTone = [255, 253, 248];
    const paperTone = cartonTone.map((channel, index) => Math.round(channel + (whiteTone[index] - channel) * paperProgress));
    document.documentElement.style.setProperty("--scroll-paper", `rgb(${paperTone.join(" ")})`);

    if (hero && scrollPosition < hero.offsetHeight) {
        hero.style.setProperty("--hero-shift", `${Math.min(scrollPosition * 0.16, 90)}px`);
    }

    framePending = false;
}

window.addEventListener("scroll", () => {
    if (!framePending) {
        window.requestAnimationFrame(updateScrollState);
        framePending = true;
    }
}, { passive: true });
window.addEventListener("resize", updateScrollState);

updateScrollState();

if (menuToggle && primaryNav) {
    menuToggle.addEventListener("click", () => {
        const isExpanded = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", String(!isExpanded));
        menuToggle.setAttribute("aria-label", isExpanded ? "فتح القائمة" : "إغلاق القائمة");
        primaryNav.classList.toggle("is-open", !isExpanded);
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => {
            menuToggle.setAttribute("aria-expanded", "false");
            menuToggle.setAttribute("aria-label", "فتح القائمة");
            primaryNav.classList.remove("is-open");
        });
    });
}

const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("is-visible");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.14 });

    revealItems.forEach((item) => revealObserver.observe(item));
} else {
    revealItems.forEach((item) => item.classList.add("is-visible"));
}